﻿Option Strict On

Public Class Form1
    'Name: Erich Wagner
    'Class: .NET Programming
    'Abstract: Homework 9 - Freezing and Boiling Points


    'Substance          Freezing Point          Boiling Point

    'Ethyl Alcohol      -173°                    172°
    'Mecury             -38°                     676°
    'Oxygen             -362°                    -306°
    'Water              32°                      212°

    Private Sub btnFreezeBoil_Click(sender As Object, e As EventArgs) Handles btnFreezeBoil.Click

        'declare variables
        Dim dblTemp As Double
        Dim strFreeze As String
        Dim strBoil As String
        'requires a valid number
        If Double.TryParse(txtTemp.Text, dblTemp) = False Then
            MessageBox.Show("Please enter in a valid number")
            txtTemp.Focus()
            Exit Sub
        End If
        'conditional inputs to make output
        Select Case dblTemp
            Case Is > 675
                strBoil = "Mercury, water, ethyl alcohol and oxygen will boil"
                strFreeze = "Nothing will freeze"
            Case 212 To 675
                strBoil = "Water, ethyl alcohol and oxygen will boil"
                strFreeze = "Nothing will freeze"
            Case 172 To 211
                strBoil = "Ethyl alcohol and oxygen will boil"
                strFreeze = "Nothing will freeze"
            Case 33 To 171
                strBoil = "Oxygen will boil"
                strFreeze = "Nothing will freeze"
            Case -37 To 32
                strBoil = "Oxygen will boil"
                strFreeze = "Water will freeze"
            Case -172 To -38
                strBoil = "Oxygen will boil"
                strFreeze = "Mecury and water will freeze"
            Case -305 To -173
                strBoil = "Oxygen will boil"
                strFreeze = "Mecury, ethyl alcohol and water will freeze"
            Case -361 To -306
                strBoil = "Nothing will boil"
                strFreeze = "Mecury, ethyl alcohol and water will freeze"
            Case Is < -361
                strBoil = "Nothing will boil"
                strFreeze = "Mecury, ethyl alcohol, water and oxygen will freeze"
        End Select
        'output
        'MessageBox.Show(strBoil + strFreeze)

        lblBoil.Text = strBoil
        lblFreeze.Text = strFreeze
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'clears data
        txtTemp.Clear()
        lblBoil.Text = String.Empty
        lblFreeze.Text = String.Empty
        'focus to textbox after clear
        txtTemp.Focus()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'close form
        Close()

    End Sub
End Class
