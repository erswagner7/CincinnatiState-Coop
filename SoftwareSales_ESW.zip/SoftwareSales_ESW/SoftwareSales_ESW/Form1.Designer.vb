﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radOneTime = New System.Windows.Forms.RadioButton()
        Me.radYearly = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkCloud = New System.Windows.Forms.CheckBox()
        Me.chkOnSite = New System.Windows.Forms.CheckBox()
        Me.chkLevel3 = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.lblOptCost = New System.Windows.Forms.Label()
        Me.lblSoftCost = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox1.Controls.Add(Me.radOneTime)
        Me.GroupBox1.Controls.Add(Me.radYearly)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(300, 230)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Licensing Options"
        '
        'radOneTime
        '
        Me.radOneTime.Location = New System.Drawing.Point(43, 100)
        Me.radOneTime.Name = "radOneTime"
        Me.radOneTime.Size = New System.Drawing.Size(150, 50)
        Me.radOneTime.TabIndex = 1
        Me.radOneTime.Text = "One-Time Purchase"
        Me.radOneTime.UseVisualStyleBackColor = True
        '
        'radYearly
        '
        Me.radYearly.Checked = True
        Me.radYearly.Location = New System.Drawing.Point(43, 44)
        Me.radYearly.Name = "radYearly"
        Me.radYearly.Size = New System.Drawing.Size(150, 50)
        Me.radYearly.TabIndex = 0
        Me.radYearly.TabStop = True
        Me.radYearly.Text = "Yearly License"
        Me.radYearly.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox2.Controls.Add(Me.chkCloud)
        Me.GroupBox2.Controls.Add(Me.chkOnSite)
        Me.GroupBox2.Controls.Add(Me.chkLevel3)
        Me.GroupBox2.Location = New System.Drawing.Point(466, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(300, 230)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Optional Features (yearly)"
        '
        'chkCloud
        '
        Me.chkCloud.Location = New System.Drawing.Point(25, 126)
        Me.chkCloud.Name = "chkCloud"
        Me.chkCloud.Size = New System.Drawing.Size(181, 24)
        Me.chkCloud.TabIndex = 2
        Me.chkCloud.Text = "Cloud Backup"
        Me.chkCloud.UseVisualStyleBackColor = True
        '
        'chkOnSite
        '
        Me.chkOnSite.Location = New System.Drawing.Point(25, 83)
        Me.chkOnSite.Name = "chkOnSite"
        Me.chkOnSite.Size = New System.Drawing.Size(181, 24)
        Me.chkOnSite.TabIndex = 1
        Me.chkOnSite.Text = "On-site Training"
        Me.chkOnSite.UseVisualStyleBackColor = True
        '
        'chkLevel3
        '
        Me.chkLevel3.Location = New System.Drawing.Point(25, 44)
        Me.chkLevel3.Name = "chkLevel3"
        Me.chkLevel3.Size = New System.Drawing.Size(181, 24)
        Me.chkLevel3.TabIndex = 0
        Me.chkLevel3.Text = "Level-3 Technical Support"
        Me.chkLevel3.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.LightGray
        Me.GroupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.GroupBox3.Controls.Add(Me.lblOptCost)
        Me.GroupBox3.Controls.Add(Me.lblSoftCost)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Location = New System.Drawing.Point(122, 248)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GroupBox3.Size = New System.Drawing.Size(550, 135)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        '
        'lblOptCost
        '
        Me.lblOptCost.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblOptCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOptCost.Location = New System.Drawing.Point(341, 79)
        Me.lblOptCost.Name = "lblOptCost"
        Me.lblOptCost.Size = New System.Drawing.Size(172, 23)
        Me.lblOptCost.TabIndex = 3
        '
        'lblSoftCost
        '
        Me.lblSoftCost.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblSoftCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSoftCost.Location = New System.Drawing.Point(341, 37)
        Me.lblSoftCost.Name = "lblSoftCost"
        Me.lblSoftCost.Size = New System.Drawing.Size(172, 23)
        Me.lblSoftCost.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(43, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(147, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Cost of optional features:"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(43, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(147, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Cost of software licensing:"
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(55, 410)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(190, 39)
        Me.btnCalc.TabIndex = 3
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(312, 410)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(190, 39)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(550, 410)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(190, 39)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gainsboro
        Me.ClientSize = New System.Drawing.Size(778, 489)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Software Sales"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents radOneTime As System.Windows.Forms.RadioButton
    Friend WithEvents radYearly As System.Windows.Forms.RadioButton
    Friend WithEvents chkCloud As System.Windows.Forms.CheckBox
    Friend WithEvents chkOnSite As System.Windows.Forms.CheckBox
    Friend WithEvents chkLevel3 As System.Windows.Forms.CheckBox
    Friend WithEvents lblOptCost As System.Windows.Forms.Label
    Friend WithEvents lblSoftCost As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnCalc As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button

End Class
