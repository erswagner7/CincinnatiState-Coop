﻿Option Strict On

Public Class Form1
    'Name: Erich Wagner
    'Abstract: Homework 8 - Software Sales Application

    Const dblYearly As Double = 5000.0
    Const dblOneTime As Double = 20000.0

    Const dblLevel As Double = 3500
    Const dblOnSite As Double = 2000
    Const dblCloud As Double = 300

    
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'declare variables

        Dim dblSoftCost As Double
        Dim dblOptCost As Double

        'licensing calculations

        If radYearly.Checked Then
            dblSoftCost = dblSoftCost + dblYearly
        Else
            dblSoftCost = dblSoftCost + dblOneTime
        End If


        'options calculations
        If chkLevel3.Checked Then
            dblOptCost = dblOptCost + dblLevel
        End If

        If chkOnSite.Checked Then
            dblOptCost = dblOptCost + dblOnSite
        End If

        If chkCloud.Checked Then
            dblOptCost = dblOptCost + dblCloud
        End If

        'display output
        lblSoftCost.Text = dblSoftCost.ToString("c")
        lblOptCost.Text = dblOptCost.ToString("c")
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clears fields

        'output clear
        lblOptCost.ResetText()
        lblSoftCost.ResetText()
        'checkbox clear
        chkCloud.Checked = False
        chkLevel3.Checked = False
        chkOnSite.Checked = False
        'radio clear
        radYearly.Checked = True
        radOneTime.Checked = False
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'closes form
        Close()

    End Sub
End Class
