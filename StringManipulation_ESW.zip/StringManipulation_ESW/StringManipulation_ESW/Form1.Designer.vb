﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnReverse = New System.Windows.Forms.Button()
        Me.btnCountWords = New System.Windows.Forms.Button()
        Me.btnCountVowels = New System.Windows.Forms.Button()
        Me.txtSentence = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtF6 = New System.Windows.Forms.TextBox()
        Me.txtF4 = New System.Windows.Forms.TextBox()
        Me.txtF2 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtF5 = New System.Windows.Forms.TextBox()
        Me.txtF3 = New System.Windows.Forms.TextBox()
        Me.txtF1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnPutTogether = New System.Windows.Forms.Button()
        Me.btnBreakApart = New System.Windows.Forms.Button()
        Me.txtRecord = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnFormatPhoneNUM = New System.Windows.Forms.Button()
        Me.txtPhoneNum = New System.Windows.Forms.TextBox()
        Me.lblFormatPhNUM = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.Step1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CountVowelsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CountWordsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReverseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Step2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BreakApartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PutTogetherToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExtraCreditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormatPhoneNumberToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnReverse)
        Me.GroupBox1.Controls.Add(Me.btnCountWords)
        Me.GroupBox1.Controls.Add(Me.btnCountVowels)
        Me.GroupBox1.Controls.Add(Me.txtSentence)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 23)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(341, 125)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Step 1"
        '
        'btnReverse
        '
        Me.btnReverse.Location = New System.Drawing.Point(221, 71)
        Me.btnReverse.Name = "btnReverse"
        Me.btnReverse.Size = New System.Drawing.Size(100, 25)
        Me.btnReverse.TabIndex = 4
        Me.btnReverse.Text = "&Reverse"
        Me.btnReverse.UseVisualStyleBackColor = True
        '
        'btnCountWords
        '
        Me.btnCountWords.Location = New System.Drawing.Point(115, 71)
        Me.btnCountWords.Name = "btnCountWords"
        Me.btnCountWords.Size = New System.Drawing.Size(100, 25)
        Me.btnCountWords.TabIndex = 3
        Me.btnCountWords.Text = "Count &Words"
        Me.btnCountWords.UseVisualStyleBackColor = True
        '
        'btnCountVowels
        '
        Me.btnCountVowels.Location = New System.Drawing.Point(10, 71)
        Me.btnCountVowels.Name = "btnCountVowels"
        Me.btnCountVowels.Size = New System.Drawing.Size(100, 25)
        Me.btnCountVowels.TabIndex = 2
        Me.btnCountVowels.Text = "Count &Vowels"
        Me.btnCountVowels.UseVisualStyleBackColor = True
        '
        'txtSentence
        '
        Me.txtSentence.Location = New System.Drawing.Point(100, 26)
        Me.txtSentence.Name = "txtSentence"
        Me.txtSentence.Size = New System.Drawing.Size(203, 20)
        Me.txtSentence.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Sentence:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtF6)
        Me.GroupBox2.Controls.Add(Me.txtF4)
        Me.GroupBox2.Controls.Add(Me.txtF2)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.txtF5)
        Me.GroupBox2.Controls.Add(Me.txtF3)
        Me.GroupBox2.Controls.Add(Me.txtF1)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.btnPutTogether)
        Me.GroupBox2.Controls.Add(Me.btnBreakApart)
        Me.GroupBox2.Controls.Add(Me.txtRecord)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 152)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(341, 161)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Step 2"
        '
        'txtF6
        '
        Me.txtF6.Location = New System.Drawing.Point(221, 121)
        Me.txtF6.Name = "txtF6"
        Me.txtF6.Size = New System.Drawing.Size(100, 20)
        Me.txtF6.TabIndex = 15
        '
        'txtF4
        '
        Me.txtF4.Location = New System.Drawing.Point(221, 95)
        Me.txtF4.Name = "txtF4"
        Me.txtF4.Size = New System.Drawing.Size(100, 20)
        Me.txtF4.TabIndex = 14
        '
        'txtF2
        '
        Me.txtF2.Location = New System.Drawing.Point(221, 69)
        Me.txtF2.Name = "txtF2"
        Me.txtF2.Size = New System.Drawing.Size(100, 20)
        Me.txtF2.TabIndex = 13
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(178, 128)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Field 6:"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(178, 98)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 13)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Field 4:"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(178, 76)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(51, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Field 2:"
        '
        'txtF5
        '
        Me.txtF5.Location = New System.Drawing.Point(72, 121)
        Me.txtF5.Name = "txtF5"
        Me.txtF5.Size = New System.Drawing.Size(100, 20)
        Me.txtF5.TabIndex = 9
        '
        'txtF3
        '
        Me.txtF3.Location = New System.Drawing.Point(72, 95)
        Me.txtF3.Name = "txtF3"
        Me.txtF3.Size = New System.Drawing.Size(100, 20)
        Me.txtF3.TabIndex = 8
        '
        'txtF1
        '
        Me.txtF1.Location = New System.Drawing.Point(72, 69)
        Me.txtF1.Name = "txtF1"
        Me.txtF1.Size = New System.Drawing.Size(100, 20)
        Me.txtF1.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(10, 121)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Field 5:"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(10, 95)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Field 3:"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(10, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Field 1:"
        '
        'btnPutTogether
        '
        Me.btnPutTogether.Location = New System.Drawing.Point(187, 39)
        Me.btnPutTogether.Name = "btnPutTogether"
        Me.btnPutTogether.Size = New System.Drawing.Size(100, 25)
        Me.btnPutTogether.TabIndex = 3
        Me.btnPutTogether.Text = "Put &Together"
        Me.btnPutTogether.UseVisualStyleBackColor = True
        '
        'btnBreakApart
        '
        Me.btnBreakApart.Location = New System.Drawing.Point(72, 39)
        Me.btnBreakApart.Name = "btnBreakApart"
        Me.btnBreakApart.Size = New System.Drawing.Size(100, 25)
        Me.btnBreakApart.TabIndex = 2
        Me.btnBreakApart.Text = "&Break Apart"
        Me.btnBreakApart.UseVisualStyleBackColor = True
        '
        'txtRecord
        '
        Me.txtRecord.Location = New System.Drawing.Point(100, 13)
        Me.txtRecord.Name = "txtRecord"
        Me.txtRecord.Size = New System.Drawing.Size(203, 20)
        Me.txtRecord.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(10, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Record:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnFormatPhoneNUM)
        Me.GroupBox3.Controls.Add(Me.txtPhoneNum)
        Me.GroupBox3.Controls.Add(Me.lblFormatPhNUM)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 319)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(341, 145)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Extra Credit"
        '
        'btnFormatPhoneNUM
        '
        Me.btnFormatPhoneNUM.Location = New System.Drawing.Point(91, 107)
        Me.btnFormatPhoneNUM.Name = "btnFormatPhoneNUM"
        Me.btnFormatPhoneNUM.Size = New System.Drawing.Size(150, 25)
        Me.btnFormatPhoneNUM.TabIndex = 4
        Me.btnFormatPhoneNUM.Text = "&Format Phone Number"
        Me.btnFormatPhoneNUM.UseVisualStyleBackColor = True
        '
        'txtPhoneNum
        '
        Me.txtPhoneNum.Location = New System.Drawing.Point(181, 25)
        Me.txtPhoneNum.Name = "txtPhoneNum"
        Me.txtPhoneNum.Size = New System.Drawing.Size(140, 20)
        Me.txtPhoneNum.TabIndex = 3
        '
        'lblFormatPhNUM
        '
        Me.lblFormatPhNUM.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblFormatPhNUM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFormatPhNUM.Location = New System.Drawing.Point(181, 69)
        Me.lblFormatPhNUM.Name = "lblFormatPhNUM"
        Me.lblFormatPhNUM.Size = New System.Drawing.Size(140, 21)
        Me.lblFormatPhNUM.TabIndex = 2
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(16, 77)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(131, 13)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Formatted Phone Number:"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(16, 32)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(81, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Phone Number:"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Step1ToolStripMenuItem, Me.Step2ToolStripMenuItem, Me.ExtraCreditToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(364, 24)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Step1ToolStripMenuItem
        '
        Me.Step1ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CountVowelsToolStripMenuItem, Me.CountWordsToolStripMenuItem, Me.ReverseToolStripMenuItem})
        Me.Step1ToolStripMenuItem.Name = "Step1ToolStripMenuItem"
        Me.Step1ToolStripMenuItem.Size = New System.Drawing.Size(51, 20)
        Me.Step1ToolStripMenuItem.Text = "Step 1"
        '
        'CountVowelsToolStripMenuItem
        '
        Me.CountVowelsToolStripMenuItem.Name = "CountVowelsToolStripMenuItem"
        Me.CountVowelsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CountVowelsToolStripMenuItem.Text = "Count Vowels"
        '
        'CountWordsToolStripMenuItem
        '
        Me.CountWordsToolStripMenuItem.Name = "CountWordsToolStripMenuItem"
        Me.CountWordsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CountWordsToolStripMenuItem.Text = "Count Words"
        '
        'ReverseToolStripMenuItem
        '
        Me.ReverseToolStripMenuItem.Name = "ReverseToolStripMenuItem"
        Me.ReverseToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ReverseToolStripMenuItem.Text = "Reverse"
        '
        'Step2ToolStripMenuItem
        '
        Me.Step2ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BreakApartToolStripMenuItem, Me.PutTogetherToolStripMenuItem})
        Me.Step2ToolStripMenuItem.Name = "Step2ToolStripMenuItem"
        Me.Step2ToolStripMenuItem.Size = New System.Drawing.Size(51, 20)
        Me.Step2ToolStripMenuItem.Text = "Step 2"
        '
        'BreakApartToolStripMenuItem
        '
        Me.BreakApartToolStripMenuItem.Name = "BreakApartToolStripMenuItem"
        Me.BreakApartToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.BreakApartToolStripMenuItem.Text = "Break Apart"
        '
        'PutTogetherToolStripMenuItem
        '
        Me.PutTogetherToolStripMenuItem.Name = "PutTogetherToolStripMenuItem"
        Me.PutTogetherToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.PutTogetherToolStripMenuItem.Text = "Put Together"
        '
        'ExtraCreditToolStripMenuItem
        '
        Me.ExtraCreditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FormatPhoneNumberToolStripMenuItem})
        Me.ExtraCreditToolStripMenuItem.Name = "ExtraCreditToolStripMenuItem"
        Me.ExtraCreditToolStripMenuItem.Size = New System.Drawing.Size(79, 20)
        Me.ExtraCreditToolStripMenuItem.Text = "Extra Credit"
        '
        'FormatPhoneNumberToolStripMenuItem
        '
        Me.FormatPhoneNumberToolStripMenuItem.Name = "FormatPhoneNumberToolStripMenuItem"
        Me.FormatPhoneNumberToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.FormatPhoneNumberToolStripMenuItem.Text = "Format Phone Number"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(364, 476)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "String Manipulation"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnReverse As System.Windows.Forms.Button
    Friend WithEvents btnCountWords As System.Windows.Forms.Button
    Friend WithEvents btnCountVowels As System.Windows.Forms.Button
    Friend WithEvents txtSentence As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtF6 As System.Windows.Forms.TextBox
    Friend WithEvents txtF4 As System.Windows.Forms.TextBox
    Friend WithEvents txtF2 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtF5 As System.Windows.Forms.TextBox
    Friend WithEvents txtF3 As System.Windows.Forms.TextBox
    Friend WithEvents txtF1 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnPutTogether As System.Windows.Forms.Button
    Friend WithEvents btnBreakApart As System.Windows.Forms.Button
    Friend WithEvents txtRecord As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnFormatPhoneNUM As System.Windows.Forms.Button
    Friend WithEvents txtPhoneNum As System.Windows.Forms.TextBox
    Friend WithEvents lblFormatPhNUM As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Step1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CountVowelsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CountWordsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReverseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Step2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BreakApartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PutTogetherToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExtraCreditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormatPhoneNumberToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
