﻿'Name Erich Wagner
'Class: .Net Programming
'Abstract: Homework 16 - String Manipulation

Option Strict On

Public Class Form1
    'Declare variables
    'Get and validate input
    'calculations
    'Display

    'Step 1 Counting Vowels, Counting Words, Reverse a sentence
    '==========================================================

    'get the sentence in the textbox txtSentence
    Private Function GetSentence(ByRef strSentence As String) As String
        strSentence = txtSentence.Text()
        Return strSentence

    End Function

    'count vowels in sentence
    Private Sub btnCountVowels_Click(sender As Object, e As EventArgs) Handles btnCountVowels.Click, CountVowelsToolStripMenuItem.Click

        'Count vowels variables
        '=======================
        Dim strSentence As String
        Dim intVowels As Integer

        'Functions and procedures
        '=========================
        GetSentence(strSentence)
        CountVowels(strSentence, intVowels)
        DisplayVowelCount(intVowels)

    End Sub

    

    'gets the vowel count
    Private Function CountVowels(ByVal strSentence As String, ByRef intVowels As Integer) As Integer


        Dim intIndex As Integer
        Dim strCurrentLetter As String

        strSentence = strSentence.ToLower
        For intIndex = 0 To strSentence.Length - 1
            strCurrentLetter = strSentence.Substring(intIndex, 1)
            If strCurrentLetter = "a" Or strCurrentLetter = "e" Or strCurrentLetter = "i" Or strCurrentLetter = "o" Or strCurrentLetter = "u" Then
                intVowels += 1
            End If
        Next

        Return intVowels
    End Function

    'Display the number of vowels in a message box
    Private Sub DisplayVowelCount(ByVal intVowels As Integer)
        MessageBox.Show("The number of vowel(s) in the sentence is " & CStr(intVowels))
    End Sub

    'counts words in sentence
    Private Sub btnCountWords_Click(sender As Object, e As EventArgs) Handles btnCountWords.Click, CountWordsToolStripMenuItem.Click

        'Count words variables
        '=======================
        Dim intWords As Integer = 1
        Dim strSentence As String = txtSentence.Text

        'Functions and procedures
        '=========================
        CountWords(strSentence, intWords)
        DisplayWordCount(intWords)

    End Sub

    'gets the word count
    Private Function CountWords(ByVal strSentence As String, ByRef intWords As Integer) As Integer

        Dim strSpaces As String

        For intIndex = 0 To strSentence.Length - 1
            strSpaces = strSentence.Substring(intIndex, 1)
            If strSpaces = " " Then
                intWords += 1
            End If
        Next

        Return intWords
    End Function

    'displays the word count in a message box
    Private Sub DisplayWordCount(intWords As Integer)
        MessageBox.Show("The number of word(s) in the sentence is " & CStr(intWords))
    End Sub

    'reverses the sentence the user gives as input
    Private Sub btnReverse_Click(sender As Object, e As EventArgs) Handles btnReverse.Click, ReverseToolStripMenuItem.Click

        'Reverse variables
        '=======================
        Dim strReverseSentence As String
        Dim strSentence As String = txtSentence.Text


        'Functions and procedures
        '=========================
        GetSentence(strSentence)
        ReverseSentence(strSentence, strReverseSentence)
        DisplayReverse(strReverseSentence)

    End Sub

    'reverse the sentence
    Private Function ReverseSentence(ByVal strSentence As String, ByRef strReverseSentence As String) As String

        Dim intIndex As Integer
        Dim strCurrentLetter As String


        For intIndex = strSentence.Length - 1 To 0 Step -1
            strCurrentLetter = strSentence.Substring(intIndex, 1)
            strReverseSentence = strReverseSentence & strCurrentLetter

        Next
        Return strReverseSentence
    End Function

    'updates the sentence textbox to the reversed sentence
    Private Sub DisplayReverse(ByVal strReverseSentence As String)
        txtSentence.Text = strReverseSentence
    End Sub


    'Step 2 Breaking the data in strRecord into several fields
    '==========================================================
    Private Function GetRecord(ByRef strRecord As String) As String
        strRecord = txtRecord.Text
        Return strRecord
    End Function

    'button that breaks apart the data in the record textbox into 6 different fields
    Private Sub btnBreakApart_Click(sender As Object, e As EventArgs) Handles btnBreakApart.Click, BreakApartToolStripMenuItem.Click
        'Break apart variables
        '======================
        Dim strRecord As String

        'Functions and procedures
        '=========================
        GetRecord(strRecord)
        BreakApartRecord(strRecord)

    End Sub

    'breaks apart record
    Private Sub BreakApartRecord(ByVal strRecord As String)
        Dim intCommaIndex As Integer
        Dim intCount As Integer
        Dim strField As String

        intCommaIndex = strRecord.IndexOf(",")
        Do Until intCommaIndex = -1 Or (intCount > 6)

            intCount += 1

            strField = strRecord.Substring(0, intCommaIndex).Trim
            DisplayField(strField, intCount)

            strRecord = strRecord.Remove(0, intCommaIndex + 1).Trim
            intCommaIndex = strRecord.IndexOf(",")

        Loop
        txtRecord.Clear()
    End Sub

    'displays the separated record into the fields
    Private Sub DisplayField(ByVal strField As String, ByVal intCount As Integer)
        'field 1
        If intCount = 1 Then
            txtF1.Text = strField
        End If

        'field 2
        If intCount = 2 Then
            txtF2.Text = strField
        End If

        'field 3
        If intCount = 3 Then
            txtF3.Text = strField
        End If

        'field 4
        If intCount = 4 Then
            txtF4.Text = strField
        End If

        'field 5
        If intCount = 5 Then
            txtF5.Text = strField
        End If

        'field 6
        If intCount = 6 Then
            txtF6.Text = strField
        End If
    End Sub

    'button that takes the data within the fields and puts it back together in the record textbox
    Private Sub btnPutTogether_Click(sender As Object, e As EventArgs) Handles btnPutTogether.Click, PutTogetherToolStripMenuItem.Click
        'Put together variables
        '=======================
        Dim strRecord As String


        'Functions and procedures
        '=========================
        GetRecord(strRecord)
        PutRecordTogether(strRecord)

    End Sub

    'puts record back together by concatenating the fields with commas in between
    Private Sub PutRecordTogether(strRecord As String)

        strRecord = txtF1.Text & ", " & txtF2.Text & ", " & txtF3.Text & ", " & txtF4.Text & ", " & txtF5.Text & ", " & txtF6.Text & ", "

        txtRecord.Text = strRecord

        txtF1.Clear()
        txtF2.Clear()
        txtF3.Clear()
        txtF4.Clear()
        txtF5.Clear()
        txtF6.Clear()

    End Sub


    'Step 3 Formatting a phone number
    '================================

    'button that formats a phone number that the user inputs
    Private Sub btnFormatPhoneNUM_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnFormatPhoneNUM.Click, FormatPhoneNumberToolStripMenuItem.Click

        'Extra Credit variables
        '===========================
        Dim strPhoneNumber As String = ""

        'Functions and procedures
        '=========================
        GetPhoneNumber(strPhoneNumber)
        FormatPhoneNumber(strPhoneNumber)

    End Sub

    'gets and validates the phone number to make sure that it is a number 
    Private Function GetPhoneNumber(ByRef strPhoneNumber As String) As String
        If IsNumeric(txtPhoneNum.Text) Then
            strPhoneNumber = txtPhoneNum.Text
        End If

        'no more than 10 digits, and no less than 10 digits
        If strPhoneNumber.Length = 10 Then
        Else
            MessageBox.Show("Please enter a phone number with only 10 digits")
            Return ""

            txtPhoneNum.Focus()
            Exit Function
        End If
        Return strPhoneNumber
    End Function

    'formats the phone number with parentheses around the area code and dashes in the phone number
    Private Sub FormatPhoneNumber(ByVal strPhoneNumber As String)
        strPhoneNumber = txtPhoneNum.Text
        lblFormatPhNUM.Text = "(" & strPhoneNumber.Substring(0, 3) & ")-" & strPhoneNumber.Substring(3, 3) & "-" & strPhoneNumber.Substring(6, 4)
    End Sub

End Class
