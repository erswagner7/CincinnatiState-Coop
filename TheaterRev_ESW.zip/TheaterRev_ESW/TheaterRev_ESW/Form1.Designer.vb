﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GBATS = New System.Windows.Forms.GroupBox()
        Me.txtAdultSold = New System.Windows.Forms.TextBox()
        Me.txtAdultPrice = New System.Windows.Forms.TextBox()
        Me.lblAdTick = New System.Windows.Forms.Label()
        Me.lblAdPrice = New System.Windows.Forms.Label()
        Me.GBGTR = New System.Windows.Forms.GroupBox()
        Me.lblTGR = New System.Windows.Forms.Label()
        Me.lblGrossCTS = New System.Windows.Forms.Label()
        Me.lblGrossATS = New System.Windows.Forms.Label()
        Me.lblTotalGross = New System.Windows.Forms.Label()
        Me.lblGrossChSales = New System.Windows.Forms.Label()
        Me.lblGrossAdSales = New System.Windows.Forms.Label()
        Me.GBCTS = New System.Windows.Forms.GroupBox()
        Me.txtChildSold = New System.Windows.Forms.TextBox()
        Me.txtChildPrice = New System.Windows.Forms.TextBox()
        Me.lblChTick = New System.Windows.Forms.Label()
        Me.lblChPrice = New System.Windows.Forms.Label()
        Me.GBNTS = New System.Windows.Forms.GroupBox()
        Me.lblTNR = New System.Windows.Forms.Label()
        Me.lblNetCTS = New System.Windows.Forms.Label()
        Me.lblNetATS = New System.Windows.Forms.Label()
        Me.lblTotalNet = New System.Windows.Forms.Label()
        Me.lblNetChSales = New System.Windows.Forms.Label()
        Me.lblNetAdSales = New System.Windows.Forms.Label()
        Me.btnCalcTickRev = New System.Windows.Forms.Button()
        Me.btnCL = New System.Windows.Forms.Button()
        Me.btnEX = New System.Windows.Forms.Button()
        Me.GBATS.SuspendLayout()
        Me.GBGTR.SuspendLayout()
        Me.GBCTS.SuspendLayout()
        Me.GBNTS.SuspendLayout()
        Me.SuspendLayout()
        '
        'GBATS
        '
        Me.GBATS.Controls.Add(Me.txtAdultSold)
        Me.GBATS.Controls.Add(Me.txtAdultPrice)
        Me.GBATS.Controls.Add(Me.lblAdTick)
        Me.GBATS.Controls.Add(Me.lblAdPrice)
        Me.GBATS.Location = New System.Drawing.Point(12, 12)
        Me.GBATS.Name = "GBATS"
        Me.GBATS.Size = New System.Drawing.Size(250, 150)
        Me.GBATS.TabIndex = 0
        Me.GBATS.TabStop = False
        Me.GBATS.Text = "Adult Ticket Sales"
        '
        'txtAdultSold
        '
        Me.txtAdultSold.Location = New System.Drawing.Point(128, 74)
        Me.txtAdultSold.Name = "txtAdultSold"
        Me.txtAdultSold.Size = New System.Drawing.Size(100, 20)
        Me.txtAdultSold.TabIndex = 9
        '
        'txtAdultPrice
        '
        Me.txtAdultPrice.Location = New System.Drawing.Point(128, 44)
        Me.txtAdultPrice.Name = "txtAdultPrice"
        Me.txtAdultPrice.Size = New System.Drawing.Size(100, 20)
        Me.txtAdultPrice.TabIndex = 8
        '
        'lblAdTick
        '
        Me.lblAdTick.Location = New System.Drawing.Point(22, 68)
        Me.lblAdTick.Name = "lblAdTick"
        Me.lblAdTick.Size = New System.Drawing.Size(100, 30)
        Me.lblAdTick.TabIndex = 7
        Me.lblAdTick.Text = "Tickets Sold:"
        Me.lblAdTick.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAdPrice
        '
        Me.lblAdPrice.Location = New System.Drawing.Point(22, 38)
        Me.lblAdPrice.Name = "lblAdPrice"
        Me.lblAdPrice.Size = New System.Drawing.Size(100, 30)
        Me.lblAdPrice.TabIndex = 0
        Me.lblAdPrice.Text = "Price per Ticket:"
        Me.lblAdPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GBGTR
        '
        Me.GBGTR.Controls.Add(Me.lblTGR)
        Me.GBGTR.Controls.Add(Me.lblGrossCTS)
        Me.GBGTR.Controls.Add(Me.lblGrossATS)
        Me.GBGTR.Controls.Add(Me.lblTotalGross)
        Me.GBGTR.Controls.Add(Me.lblGrossChSales)
        Me.GBGTR.Controls.Add(Me.lblGrossAdSales)
        Me.GBGTR.Location = New System.Drawing.Point(12, 168)
        Me.GBGTR.Name = "GBGTR"
        Me.GBGTR.Size = New System.Drawing.Size(250, 150)
        Me.GBGTR.TabIndex = 1
        Me.GBGTR.TabStop = False
        Me.GBGTR.Text = "Gross Ticket Revenue"
        '
        'lblTGR
        '
        Me.lblTGR.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTGR.Location = New System.Drawing.Point(144, 98)
        Me.lblTGR.Name = "lblTGR"
        Me.lblTGR.Size = New System.Drawing.Size(100, 23)
        Me.lblTGR.TabIndex = 5
        Me.lblTGR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGrossCTS
        '
        Me.lblGrossCTS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGrossCTS.Location = New System.Drawing.Point(144, 64)
        Me.lblGrossCTS.Name = "lblGrossCTS"
        Me.lblGrossCTS.Size = New System.Drawing.Size(100, 23)
        Me.lblGrossCTS.TabIndex = 4
        Me.lblGrossCTS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGrossATS
        '
        Me.lblGrossATS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGrossATS.Location = New System.Drawing.Point(144, 27)
        Me.lblGrossATS.Name = "lblGrossATS"
        Me.lblGrossATS.Size = New System.Drawing.Size(100, 23)
        Me.lblGrossATS.TabIndex = 3
        Me.lblGrossATS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotalGross
        '
        Me.lblTotalGross.Location = New System.Drawing.Point(6, 98)
        Me.lblTotalGross.Name = "lblTotalGross"
        Me.lblTotalGross.Size = New System.Drawing.Size(116, 35)
        Me.lblTotalGross.TabIndex = 2
        Me.lblTotalGross.Text = "Total Gross Revenue for Ticket Sales:"
        Me.lblTotalGross.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGrossChSales
        '
        Me.lblGrossChSales.Location = New System.Drawing.Point(22, 64)
        Me.lblGrossChSales.Name = "lblGrossChSales"
        Me.lblGrossChSales.Size = New System.Drawing.Size(100, 23)
        Me.lblGrossChSales.TabIndex = 1
        Me.lblGrossChSales.Text = "Child Ticket Sales:"
        Me.lblGrossChSales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGrossAdSales
        '
        Me.lblGrossAdSales.Location = New System.Drawing.Point(22, 27)
        Me.lblGrossAdSales.Name = "lblGrossAdSales"
        Me.lblGrossAdSales.Size = New System.Drawing.Size(100, 23)
        Me.lblGrossAdSales.TabIndex = 0
        Me.lblGrossAdSales.Text = "Adult Ticket Sales:"
        Me.lblGrossAdSales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GBCTS
        '
        Me.GBCTS.Controls.Add(Me.txtChildSold)
        Me.GBCTS.Controls.Add(Me.txtChildPrice)
        Me.GBCTS.Controls.Add(Me.lblChTick)
        Me.GBCTS.Controls.Add(Me.lblChPrice)
        Me.GBCTS.Location = New System.Drawing.Point(296, 12)
        Me.GBCTS.Name = "GBCTS"
        Me.GBCTS.Size = New System.Drawing.Size(250, 150)
        Me.GBCTS.TabIndex = 2
        Me.GBCTS.TabStop = False
        Me.GBCTS.Text = "Child Ticket Sales"
        '
        'txtChildSold
        '
        Me.txtChildSold.Location = New System.Drawing.Point(133, 74)
        Me.txtChildSold.Name = "txtChildSold"
        Me.txtChildSold.Size = New System.Drawing.Size(100, 20)
        Me.txtChildSold.TabIndex = 13
        '
        'txtChildPrice
        '
        Me.txtChildPrice.Location = New System.Drawing.Point(133, 44)
        Me.txtChildPrice.Name = "txtChildPrice"
        Me.txtChildPrice.Size = New System.Drawing.Size(100, 20)
        Me.txtChildPrice.TabIndex = 12
        '
        'lblChTick
        '
        Me.lblChTick.Location = New System.Drawing.Point(27, 68)
        Me.lblChTick.Name = "lblChTick"
        Me.lblChTick.Size = New System.Drawing.Size(100, 30)
        Me.lblChTick.TabIndex = 11
        Me.lblChTick.Text = "Tickets Sold:"
        Me.lblChTick.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblChPrice
        '
        Me.lblChPrice.Location = New System.Drawing.Point(27, 38)
        Me.lblChPrice.Name = "lblChPrice"
        Me.lblChPrice.Size = New System.Drawing.Size(100, 30)
        Me.lblChPrice.TabIndex = 10
        Me.lblChPrice.Text = "Price per Ticket:"
        Me.lblChPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GBNTS
        '
        Me.GBNTS.Controls.Add(Me.lblTNR)
        Me.GBNTS.Controls.Add(Me.lblNetCTS)
        Me.GBNTS.Controls.Add(Me.lblNetATS)
        Me.GBNTS.Controls.Add(Me.lblTotalNet)
        Me.GBNTS.Controls.Add(Me.lblNetChSales)
        Me.GBNTS.Controls.Add(Me.lblNetAdSales)
        Me.GBNTS.Location = New System.Drawing.Point(296, 168)
        Me.GBNTS.Name = "GBNTS"
        Me.GBNTS.Size = New System.Drawing.Size(250, 150)
        Me.GBNTS.TabIndex = 3
        Me.GBNTS.TabStop = False
        Me.GBNTS.Text = "Net Ticket Revenue"
        '
        'lblTNR
        '
        Me.lblTNR.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTNR.Location = New System.Drawing.Point(133, 98)
        Me.lblTNR.Name = "lblTNR"
        Me.lblTNR.Size = New System.Drawing.Size(100, 23)
        Me.lblTNR.TabIndex = 11
        Me.lblTNR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNetCTS
        '
        Me.lblNetCTS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNetCTS.Location = New System.Drawing.Point(133, 64)
        Me.lblNetCTS.Name = "lblNetCTS"
        Me.lblNetCTS.Size = New System.Drawing.Size(100, 23)
        Me.lblNetCTS.TabIndex = 10
        Me.lblNetCTS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNetATS
        '
        Me.lblNetATS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNetATS.Location = New System.Drawing.Point(133, 27)
        Me.lblNetATS.Name = "lblNetATS"
        Me.lblNetATS.Size = New System.Drawing.Size(100, 23)
        Me.lblNetATS.TabIndex = 9
        Me.lblNetATS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotalNet
        '
        Me.lblTotalNet.Location = New System.Drawing.Point(6, 98)
        Me.lblTotalNet.Name = "lblTotalNet"
        Me.lblTotalNet.Size = New System.Drawing.Size(116, 35)
        Me.lblTotalNet.TabIndex = 8
        Me.lblTotalNet.Text = "Total Net Revenue for Ticket Sales:"
        Me.lblTotalNet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNetChSales
        '
        Me.lblNetChSales.Location = New System.Drawing.Point(27, 64)
        Me.lblNetChSales.Name = "lblNetChSales"
        Me.lblNetChSales.Size = New System.Drawing.Size(100, 23)
        Me.lblNetChSales.TabIndex = 7
        Me.lblNetChSales.Text = "Child Ticket Sales:"
        Me.lblNetChSales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNetAdSales
        '
        Me.lblNetAdSales.Location = New System.Drawing.Point(27, 27)
        Me.lblNetAdSales.Name = "lblNetAdSales"
        Me.lblNetAdSales.Size = New System.Drawing.Size(100, 23)
        Me.lblNetAdSales.TabIndex = 6
        Me.lblNetAdSales.Text = "Adult Ticket Sales:"
        Me.lblNetAdSales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnCalcTickRev
        '
        Me.btnCalcTickRev.Location = New System.Drawing.Point(12, 342)
        Me.btnCalcTickRev.Name = "btnCalcTickRev"
        Me.btnCalcTickRev.Size = New System.Drawing.Size(250, 80)
        Me.btnCalcTickRev.TabIndex = 4
        Me.btnCalcTickRev.Text = "&Calculate Ticket Revenue"
        Me.btnCalcTickRev.UseVisualStyleBackColor = True
        '
        'btnCL
        '
        Me.btnCL.Location = New System.Drawing.Point(296, 342)
        Me.btnCL.Name = "btnCL"
        Me.btnCL.Size = New System.Drawing.Size(250, 30)
        Me.btnCL.TabIndex = 5
        Me.btnCL.Text = "Cl&ear"
        Me.btnCL.UseVisualStyleBackColor = True
        '
        'btnEX
        '
        Me.btnEX.Location = New System.Drawing.Point(296, 392)
        Me.btnEX.Name = "btnEX"
        Me.btnEX.Size = New System.Drawing.Size(250, 30)
        Me.btnEX.TabIndex = 6
        Me.btnEX.Text = "E&xit"
        Me.btnEX.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(573, 460)
        Me.Controls.Add(Me.btnEX)
        Me.Controls.Add(Me.btnCL)
        Me.Controls.Add(Me.btnCalcTickRev)
        Me.Controls.Add(Me.GBNTS)
        Me.Controls.Add(Me.GBCTS)
        Me.Controls.Add(Me.GBGTR)
        Me.Controls.Add(Me.GBATS)
        Me.Name = "Form1"
        Me.Text = "Theater Revenue"
        Me.GBATS.ResumeLayout(False)
        Me.GBATS.PerformLayout()
        Me.GBGTR.ResumeLayout(False)
        Me.GBCTS.ResumeLayout(False)
        Me.GBCTS.PerformLayout()
        Me.GBNTS.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GBATS As System.Windows.Forms.GroupBox
    Friend WithEvents GBGTR As System.Windows.Forms.GroupBox
    Friend WithEvents GBCTS As System.Windows.Forms.GroupBox
    Friend WithEvents GBNTS As System.Windows.Forms.GroupBox
    Friend WithEvents btnCalcTickRev As System.Windows.Forms.Button
    Friend WithEvents btnCL As System.Windows.Forms.Button
    Friend WithEvents btnEX As System.Windows.Forms.Button
    Friend WithEvents txtAdultSold As System.Windows.Forms.TextBox
    Friend WithEvents txtAdultPrice As System.Windows.Forms.TextBox
    Friend WithEvents lblAdTick As System.Windows.Forms.Label
    Friend WithEvents lblAdPrice As System.Windows.Forms.Label
    Friend WithEvents lblTGR As System.Windows.Forms.Label
    Friend WithEvents lblGrossCTS As System.Windows.Forms.Label
    Friend WithEvents lblGrossATS As System.Windows.Forms.Label
    Friend WithEvents lblTotalGross As System.Windows.Forms.Label
    Friend WithEvents lblGrossChSales As System.Windows.Forms.Label
    Friend WithEvents lblGrossAdSales As System.Windows.Forms.Label
    Friend WithEvents txtChildSold As System.Windows.Forms.TextBox
    Friend WithEvents txtChildPrice As System.Windows.Forms.TextBox
    Friend WithEvents lblChTick As System.Windows.Forms.Label
    Friend WithEvents lblChPrice As System.Windows.Forms.Label
    Friend WithEvents lblTNR As System.Windows.Forms.Label
    Friend WithEvents lblNetCTS As System.Windows.Forms.Label
    Friend WithEvents lblNetATS As System.Windows.Forms.Label
    Friend WithEvents lblTotalNet As System.Windows.Forms.Label
    Friend WithEvents lblNetChSales As System.Windows.Forms.Label
    Friend WithEvents lblNetAdSales As System.Windows.Forms.Label

End Class
