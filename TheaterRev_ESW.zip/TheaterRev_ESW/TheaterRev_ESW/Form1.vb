﻿Public Class Form1

    Private Sub btnCalcTickRev_Click(sender As Object, e As EventArgs) Handles btnCalcTickRev.Click
        Dim decGrossATS As Decimal
        Dim decGrossCTS As Decimal
        Dim decTGR As Decimal
        Dim decNetATS As Decimal
        Dim decNetCTS As Decimal
        Dim decTNR As Decimal
        Dim intAdultSold As Integer
        Dim decAdultPrice As Decimal
        Dim intChildSold As Integer
        Dim decChildPrice As Decimal
        Try
            'Gross Adult Ticket Sales
            intAdultSold = CInt(txtAdultSold.Text)
            decAdultPrice = CDec(txtAdultPrice.Text)
            decGrossATS = decAdultPrice * intAdultSold
            lblGrossATS.Text = decGrossATS.ToString("c")
        Catch
            MessageBox.Show("Please try again, and enter a number.")
        End Try
        Try
            'Gross Child Ticket Sales
            intChildSold = CInt(txtChildSold.Text)
            decChildPrice = CDec(txtChildPrice.Text)
            decGrossCTS = decChildPrice * intChildSold
            lblGrossCTS.Text = decGrossCTS.ToString("C")
        Catch
            MessageBox.Show("Please try again, and enter a number.")
        End Try
        Try
            'Total Gross Revenue
            decTGR = decGrossATS + decGrossCTS
            lblTGR.Text = decTGR.ToString("c")
        Catch
            MessageBox.Show("Please try again, and enter a number.")
        End Try
        Try
            'Net Adult Ticket Sales

            intAdultSold = CInt(txtAdultSold.Text)
            decAdultPrice = CDec(txtAdultPrice.Text)
            decNetATS = (decAdultPrice * intAdultSold) * 0.2
            lblNetATS.Text = decNetATS.ToString("c")
        Catch
            MessageBox.Show("Please try again, and enter a number.")
        End Try
        Try
            'Net Child Ticket Sales

            intChildSold = CInt(txtChildSold.Text)
            decChildPrice = CDec(txtChildPrice.Text)
            decNetCTS = decChildPrice * intChildSold * 0.2
            lblNetCTS.Text = decNetCTS.ToString("c")
        Catch
            MessageBox.Show("Please try again, and enter a number.")
        End Try
        Try
            'Total Net Revenue

            decTNR = decNetATS + decNetCTS
            lblTNR.Text = decTNR.ToString("c")
        Catch
            MessageBox.Show("Please try again, and enter a number.")
        End Try
    End Sub
    'Clear
    Private Sub btnCL_Click(sender As Object, e As EventArgs) Handles btnCL.Click
        txtAdultPrice.Clear()
        txtAdultSold.Clear()
        txtChildPrice.Clear()
        txtChildSold.Clear()
        lblGrossATS.Text = String.Empty
        lblGrossCTS.Text = String.Empty
        lblTGR.Text = String.Empty
        lblNetCTS.Text = String.Empty
        lblNetATS.Text = String.Empty
        lblTNR.Text = String.Empty
    End Sub
    'Exit
    Private Sub btnEX_Click(sender As Object, e As EventArgs) Handles btnEX.Click
        Me.Close()
    End Sub
End Class
