﻿
Option Strict On
Option Explicit On


'Startup when the program is executed

Module ProgramStartup

    Public Sub Main()
        Dim frmSplashPageNew As New frmSplashPage()
        Dim frmMainNew As New frmMain()
        frmSplashPageNew.ShowDialog()
        frmMainNew.ShowDialog()
    End Sub

End Module
