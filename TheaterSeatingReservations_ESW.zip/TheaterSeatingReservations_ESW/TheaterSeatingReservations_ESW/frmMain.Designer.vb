﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlTheaterSeats = New System.Windows.Forms.Panel()
        Me.lblPromptEmpty = New System.Windows.Forms.Label()
        Me.lblPromptFull = New System.Windows.Forms.Label()
        Me.lblEmpty = New System.Windows.Forms.Label()
        Me.lblFull = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SeatsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlTheaterSeats
        '
        Me.pnlTheaterSeats.AutoScroll = True
        Me.pnlTheaterSeats.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlTheaterSeats.Location = New System.Drawing.Point(0, 96)
        Me.pnlTheaterSeats.Name = "pnlTheaterSeats"
        Me.pnlTheaterSeats.Size = New System.Drawing.Size(334, 382)
        Me.pnlTheaterSeats.TabIndex = 0
        '
        'lblPromptEmpty
        '
        Me.lblPromptEmpty.Location = New System.Drawing.Point(12, 62)
        Me.lblPromptEmpty.Name = "lblPromptEmpty"
        Me.lblPromptEmpty.Size = New System.Drawing.Size(56, 16)
        Me.lblPromptEmpty.TabIndex = 9
        Me.lblPromptEmpty.Text = "Empty"
        Me.lblPromptEmpty.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPromptFull
        '
        Me.lblPromptFull.Location = New System.Drawing.Point(12, 38)
        Me.lblPromptFull.Name = "lblPromptFull"
        Me.lblPromptFull.Size = New System.Drawing.Size(56, 16)
        Me.lblPromptFull.TabIndex = 8
        Me.lblPromptFull.Text = "Full"
        Me.lblPromptFull.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblEmpty
        '
        Me.lblEmpty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblEmpty.Location = New System.Drawing.Point(68, 62)
        Me.lblEmpty.Name = "lblEmpty"
        Me.lblEmpty.Size = New System.Drawing.Size(56, 16)
        Me.lblEmpty.TabIndex = 7
        '
        'lblFull
        '
        Me.lblFull.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFull.Location = New System.Drawing.Point(68, 38)
        Me.lblFull.Name = "lblFull"
        Me.lblFull.Size = New System.Drawing.Size(56, 16)
        Me.lblFull.TabIndex = 6
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.SeatsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(334, 24)
        Me.MenuStrip1.TabIndex = 10
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(92, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'SeatsToolStripMenuItem
        '
        Me.SeatsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClearToolStripMenuItem})
        Me.SeatsToolStripMenuItem.Name = "SeatsToolStripMenuItem"
        Me.SeatsToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.SeatsToolStripMenuItem.Text = "Seats"
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ClearToolStripMenuItem.Text = "Clear"
        '
        'frmMain
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit
        Me.ClientSize = New System.Drawing.Size(334, 478)
        Me.Controls.Add(Me.lblPromptEmpty)
        Me.Controls.Add(Me.lblPromptFull)
        Me.Controls.Add(Me.lblEmpty)
        Me.Controls.Add(Me.lblFull)
        Me.Controls.Add(Me.pnlTheaterSeats)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "frmMain"
        Me.Text = "Theater Seating Reservations"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlTheaterSeats As System.Windows.Forms.Panel
    Friend WithEvents lblPromptEmpty As System.Windows.Forms.Label
    Friend WithEvents lblPromptFull As System.Windows.Forms.Label
    Friend WithEvents lblEmpty As System.Windows.Forms.Label
    Friend WithEvents lblFull As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SeatsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
