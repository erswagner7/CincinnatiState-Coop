﻿'Name: Erich Wagner
'Class: .Net Programming 2
'Abstract: Homework 5 - Theater Seating Reservations

Option Strict On
Option Explicit On

Public Class frmMain
    Inherits System.Windows.Forms.Form

    Private chkSeats(,) As System.Windows.Forms.CheckBox
    Private lblRow() As System.Windows.Forms.Label

    Private Const cintCheckBoxHeight As Integer = 15
    Private Const cintCheckBoxWidth As Integer = 15

    Private Const cintSeats As Integer = 10
    Private Const cintRows As Integer = 25

    Private mintFull As Integer
    Private mintEmpty As Integer

    Private pntCurrent As System.Drawing.Point

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim pintSeatCurrent, pintRowCurrent As Integer


        ReDim chkSeats(cintSeats, cintRows)
        ReDim lblRow(cintRows)

        mintEmpty = cintSeats * cintRows

        For pintSeatCurrent = 0 To cintSeats - 1
            For pintRowCurrent = 0 To cintRows - 1
                pntCurrent = New Point((pintSeatCurrent + 1) * cintCheckBoxWidth, _
                    (pintRowCurrent + 1) * cintCheckBoxHeight)
                Call CreateCheckBox(pintSeatCurrent, pintRowCurrent, pntCurrent)
            Next
        Next

        For pintRowCurrent = 0 To cintRows - 1
            Call CreateLabel(pintRowCurrent)
            lblRow(pintRowCurrent).Left = 120
            lblRow(pintRowCurrent).Top = (pintRowCurrent + 1) * cintCheckBoxHeight
            lblRow(pintRowCurrent).Height = 15
            lblRow(pintRowCurrent).Width = 25
        Next

    End Sub

    Private Sub CreateCheckBox(ByVal pintSeatCurrent As Integer, ByVal pintRowcurrent As Integer, ByVal pnt As Point)

        ' Create an instance of the CheckBox control and make it visible.
        chkSeats(pintSeatCurrent, pintRowcurrent) = New CheckBox()
        chkSeats(pintSeatCurrent, pintRowcurrent).Visible = True

        ' Define the size of the CheckBox control instance by creating an 
        ' instance of the Size structure and assigning a value to the Size
        ' property.
        chkSeats(pintSeatCurrent, pintRowcurrent).Size = _
            New System.Drawing.Size(cintCheckBoxWidth, cintCheckBoxHeight)

        ' Define the position of the CheckBox control instance.
        chkSeats(pintSeatCurrent, pintRowcurrent).Location = pnt

        ' Add the event handler for the newly created CheckBox control instance. 
        ' The procedure named chkSeats_CheckChanged will handle the CheckedChanged event for
        ' all of the created check boxes.
        AddHandler chkSeats(pintSeatCurrent, pintRowcurrent).CheckedChanged, _
            AddressOf chkseats_CheckedChanged

        ' Finally, add the newly creted CheckBox control instance to the Controls 
        ' collection for the Panel. Note that by adding the control instance to the
        ' Controls collection of the Panel rather than the form, the control instances
        ' will be contained by the Panel. The reason is simple. The CheckBox control
        ' instances will scroll with the Panel instead of the form.
        pnlTheaterSeats.Controls.Add(chkSeats(pintSeatCurrent, pintRowcurrent))
    End Sub


    Private Sub CreateLabel(ByVal pintRowCurrent As Integer)
        lblRow(pintRowCurrent) = New Label()
        lblRow(pintRowCurrent).Visible = True
        lblRow(pintRowCurrent).Text = (pintRowCurrent + 1).ToString()
        pnlTheaterSeats.Controls.Add(lblRow(pintRowCurrent))
    End Sub

    Private Sub chkseats_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

        ' Declare a varible to store the CheckBox.
        Dim chkCurrent As System.Windows.Forms.CheckBox

        ' Again, because sender is of type System.Object, explicitly convert
        ' the argument to a check box using the CType function
        chkCurrent = CType(sender, System.Windows.Forms.CheckBox)

        ' If the check box is checked, increment the number of occupied seats
        ' and decrement the number of empty seats. If the check box is not checked,
        ' then do the reverse.
        Select Case chkCurrent.Checked
            Case True
                mintFull += 1
                mintEmpty -= 1
            Case False
                mintFull -= 1
                mintEmpty += 1
        End Select

        ' Display the results in the labels.
        lblFull.Text = mintFull.ToString()
        lblEmpty.Text = mintEmpty.ToString()
    End Sub
    Private Sub ClearToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearToolStripMenuItem.Click
        Dim ctlCurrent As Control
        Dim chkCurrent As CheckBox

        ' The For Each loop enumerates the Controls collection for the 
        ' Panel rather than the form.
        For Each ctlCurrent In pnlTheaterSeats.Controls
            ' Check that the type of the control instance is a CheckBox. 
            ' Labels are also contained by the Panel. If the control instance
            ' is a CheckBox, then remove the check mark by setting the Checked property
            ' to False.
            If TypeOf (ctlCurrent) Is System.Windows.Forms.CheckBox Then
                chkCurrent = CType(ctlCurrent, System.Windows.Forms.CheckBox)
                chkCurrent.Checked = False
            End If
        Next
        lblFull.Text = ""
        lblEmpty.Text = ""
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Close()
    End Sub

End Class
