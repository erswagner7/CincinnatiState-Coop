﻿
Option Strict On
Option Explicit On

Public Class frmSplashPage
    Inherits System.Windows.Forms.Form



    Private Sub tmrClose_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrClose.Tick
        Me.Close()
    End Sub

    Private Sub frmSplashPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class